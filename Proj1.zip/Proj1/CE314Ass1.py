import fileinput


## This function goes through the created vocabulary list and counts each word
## the counted words are then appended to the answer list.
def ansList(vocab):
    a = 0
    while a < len(vocab):
        countWrd = wordList.count(vocab[a])
        answer.append(countWrd)
        a = a + 1
    return (answer)


## This function finds the length of the list of words  and applies the unigram formulae
## and returns the answers within answerList with adequate formatting 
def test3(answer):
    listLength = len(wordList)
    x = 0
    answerList = []
    while x < len(answer):
        Pw = answer[x] / listLength
        rndUp = ("{0:.5f}".format(Pw))
        stringt = str(vocab[x] + ':' + rndUp)
        answerList.append(stringt)
        x = x + 1
    print('  '.join(answerList))
    print()
    return


## This function calculates the result of the Laplace formulae
## where 1 is added to each word in the answer list and is  divided by the total number of words i.e. wordList
## plus total number of words in the vocabulary i.e. vocab
def test2(answer):
    ## Laplace smoothing - question 5a
    y = 0
    smoothAns = []
    answerList = []
    while y < len(answer):
        smoothCount = (answer[y] + 1) / (len(wordList) + len(vocab))
        rndUp = ("{0:.5f}".format(smoothCount))
        stringt2 = str(vocab[y] + ':' + rndUp)
        answerList.append(stringt2)
        smoothAns.append(rndUp)
        y = y + 1

    print('  '.join(answerList))

    return


## This function takes in arguments from wordList and applies Bigram and then appends answers given
## to a new list named totBiAns - for unsmoothed model 
def test1(wordListBI):
    z = 0
    listCount = 0
    biAns = []
    answerList = []
    pairCount = 0
    totalWrds = []
    sumList = []
    while z < len(answer) + 1:
        for i in range(len(vocab)):
            a = 0
            b = 1
            for j in range(len(wordListBI)):
                if wordListBI[a] == vocab[z] and wordListBI[b] == vocab[i]:
                    pairCount = pairCount + 1
                j = j + 1
                a = a + 1
                b = b + 1
            totalWrds.append(pairCount)
            pairCount = 0
        totalWrds.pop(-2)
        sumList.append(totalWrds)
        totalWrds = []
        z = z + 1
        i = i + 1
        totBiAns = []
        for o in range(len(sumList)):
            check = sumList[o]
            for p in range(len(check)):
                if o == 0:
                    div = check[p] / 4
                if o == 1:
                    div = check[p] / 5
                if o == 2:
                    div = check[p] / 6
                if o == 3:
                    try:
                        div = check[p] / 0
                    except:
                        div = (check[p]) / 1
                if o == 4:
                    div = check[p] / 3
                rndUp_2 = ("{0:.5f}".format(div))
                x = check[p]
                stringt3 = str(x) + ':' + rndUp_2
                answerList.append(stringt3)
                biAns.append(rndUp_2)
            totBiAns.append(biAns)
            biAns = []
    return (totBiAns)


## This function takes in arguments from wordList and applies Bigram and then appends answers given
## to a new list named totBiAns - for smoothed model
def test4(wordListBI):
    z = 0
    listCount = 0
    biAns = []
    answerList = []
    a = 0
    b = 1
    pairCount = 0
    totalWrds = []
    sumList = []
    v = 5
    print(" - Smoothed - ")
    while z < len(answer) + 1:
        for i in range(len(vocab)):
            a = 0
            b = 1
            for j in range(len(wordListBI)):
                if wordListBI[a] == vocab[z] and wordListBI[b] == vocab[i]:
                    pairCount = pairCount + 1
                j = j + 1
                a = a + 1
                b = b + 1
            totalWrds.append(pairCount)
            pairCount = 0
        totalWrds.pop(-2)

        sumList.append(totalWrds)
        totalWrds = []
        z = z + 1
        i = i + 1

        totBiAns = []
        for o in range(len(sumList)):

            check = sumList[o]
            for p in range(len(check)):
                if o == 0:
                    div = (check[p] + 1) / (4 + v)
                if o == 1:
                    div = (check[p] + 1) / (5 + v)
                if o == 2:
                    div = (check[p] + 1) / (6 + v)
                if o == 3:
                    div = (check[p] + 1) / v
                if o == 4:
                    div = (check[p] + 1) / (3 + v)
                rndUp_2 = ("{0:.5f}".format(div))
                x = check[p]
                stringt3 = str(x) + ':' + rndUp_2
                answerList.append(stringt3)
                biAns.append(rndUp_2)
            totBiAns.append(biAns)
            biAns = []
    return (totBiAns)


####################################################################################
wordList = [];
tWCount = 0

print("---------------- Toy dataset ------------------")
print("=== UNIGRAM MODEL ===")
print(" - Unsmoothed - ")
fileR1 = open('sampledata.txt', 'r')
for line in fileR1:
    line = line.split()[1:-1]
    for word in line:
        wordList.append(word)

answer = []
vocab = ['a', 'b', 'c', 'UNK']

answer = ansList(vocab)

test3(answer)

print(" - Smoothed - ")
test2(answer)

## Bigram - question 5b############################################################
wordListBI = []
print("=== BIGRAM MODEL ===")
print(" - Unsmoothed - ")
fileR1 = open('sampledata.txt', 'r')
for line in fileR1:
    line = line.split()
    for newWord in line:
        wordListBI.append(newWord)

vocab.append('<s>')
vocab.append('</s>')

totBiAns = test1(wordListBI)
for line in totBiAns:
    print(line)

###################################################################################  

totBiAns = test4(wordListBI)
for line in totBiAns:
    print(line)
