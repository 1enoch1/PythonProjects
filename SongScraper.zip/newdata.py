import io
import fileinput
import os
import sys
import requests
from bs4 import BeautifulSoup
from pip._vendor.distlib.compat import raw_input

fileList = []
while True:
    textList = []
    rapper = input("artist: ").replace(" ", "").lower()
    rap_song = input("song: ").replace(" ", "").lower()

    filename = raw_input("Enter a file to write lyrics to: ")
    if filename == "quit":
        sys.exit(0)
    else:
        censor = input("Enter the curse word that you want censored: ")

    for line in fileinput.input(filename, inplace=True):
        line = line.replace(censor, 'CENSORED')
        fileList.extend(line.split())
        print(line, end='')
    print(fileList)

    assert os.path.exists(filename)
    print()
    print("awesome found it")

    #
    url = "http://www.azlyrics.com/lyrics/%s/%s.html" % (rapper, rap_song)

    # make the default request
    try:
        r = requests.get(url)
        r.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(e)

    print('\nconnected to %s' % url)

    # act like a mac
    headers = {
        'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.112 Safari/534.30"}

    # make a request for the data
    r = requests.get(url, headers=headers)

    # convert the response text to soup
    soup = BeautifulSoup(r.text, "lxml")

    # get the goods
    for lyrics1 in soup.find_all("div", {"class": None}):
        if len(lyrics1.text) == 0:
            pass
            textList.append(lyrics1.text)

    # check for cursing and explicit words
    with open(filename, 'r+', encoding='utf8') as file:
        for lyrics1 in soup.find_all("div", {"class": None}):
            if len(lyrics1.text) == 0:
                pass
            print(lyrics1.text)
            file.write(str(lyrics1))
            print()

    # combine profanity words into one file
    with open('bad-words.txt', 'r+', encoding='utf8') as f1, \
            open('swearWords.txt', 'r+', encoding='utf8') as f2, \
            open("profanity.txt", "w") as f3:
        f3.write(f1.read().strip() + f2.read().strip())
