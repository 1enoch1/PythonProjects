import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.multiclass import OneVsOneClassifier
from sklearn.multiclass import OneVsRestClassifier
import csv
import nltk
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from sklearn.feature_extraction import text

"""
Code produced by Mohammed Rashid Matin and Enoch Offiah
Task 2 Assignment 1 Sentiment Classifier
This code requires the following modules to be installed:
- Pandas
- NLTK
- Scikit-learn
- Numpy
"""


# Function tokenize(text) takes text as an argument and removes all characters that contain numbers.
# From inside the definition the tokens are stemmed and then returned are the stemmed tokens.
def tokenize(text):
    text = nltk.re.sub("[^a-zA-Z]", " ", text)
    tokens = nltk.word_tokenize(text)

    res = stemTokens(tokens)

    return res


# This function stems the tokens which uses PorterStemmer. It has been proven to be better than the
# Snowball stemmer. The function is called from within the tokenize function and the tokens are passed as input.
def stemTokens(tokens):
    stemmer = nltk.PorterStemmer()
    stemmed = []
    for token in tokens:
        stemmed.append(stemmer.stem(token))
    return stemmed


# The purpose of CSV write is to write the classification along with the PhraseID to a csv file which can be uploaded
# to the Kaggle Competition. It takes a list of tuples of predicted sentiments and iterates over writing a row per tuple.
def csvwrite(predictions):
    with open('CE807_assignment1_enoch_offiah.csv', 'w', newline='') as csvfile:
        fieldnames = ['PhraseId', 'Sentiment']

        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for x in predictions:
            # print(x)
            # writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writerow({'PhraseId': x[0], 'Sentiment': x[1]})


# ----------------------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------------------

# Pandas is used to load the tsv (csv) files into a dataframe with ease.
train = pd.read_csv('train.tsv', sep='\t')
test = pd.read_csv('test.tsv', sep='\t')

train_data = []

y_train = train.Sentiment

targets = train['Sentiment'].values

# The pipeline produced that uses CountVectorizer with special parameters.
# The bigram model is implemented
# The min_df value is set to 0.000040 after extensive testing
# Tf-idf transformer is used followed by a OneVsOneClassifier
text_clf = Pipeline([('vect', CountVectorizer(
    analyzer="word",
    tokenizer=tokenize,
    preprocessor=None,
    stop_words={text.ENGLISH_STOP_WORDS},
    lowercase=True,
    # max_df = 1.0,
    min_df=0.000040,
    # min_df = 1,
    ngram_range=(1, 2)
)), ('tfidf', TfidfTransformer()), ('lSVC', OneVsOneClassifier(LinearSVC(C=0.32)))])

print("------------------------------------------")
print("Mohammed Rashid Matin and Enoch Offiah")
print("CE807 Text Analytics Assignment 1")
print("Building a classifier for the Rotten Tomatoes Dataset")
print()
print("------------------------------------------")

# doc_news = ['A series', 'adge', 'good', 'none of which amounts to a good story']

text_clf.fit(train['Phrase'].values, targets)
# predictions = text_clf.predict(doc_news)


parameters = {'ngram_range': [(1, 1), (1, 2)],
              'tfidf__use_idf': (True, False),
              'clf__alpha': (1e-2, 1e-3)}

testlist = []

print("Loading test data...")

# This for loop iterates over the test data to add the phrase id and phrase to the testlist as a tuple.
for i in range(0, len(test['PhraseId'])):
    phraseid = test.iloc[i]['PhraseId']
    phrase = test.iloc[i]['Phrase']
    testlist.append((phraseid, phrase))

print("Test data loaded.")
print("----------------------------------------")

# Two lists are created. One for the bag of words representation of each phrase.
# Class predictions contains a list of tuples that contain the phraseid and the predicted sentiment id.
classpredictions = []
testbagofwords = []

print("predicting sentiment id for test data...")

# for loop which adds the text from each phrase to a list.
for x in testlist:
    testbagofwords.append(x[1])

# predictions are made on each of the phrases
prediction = text_clf.predict(testbagofwords)

count = 0
# As predictions are made on a seperate list the two must be combined as a tuple.
# The predictions and phraseid tuple to the classpredictions list.
for x in testlist:
    phraseid = x[0]
    predictvalue = prediction[count]

    classpredictions.append((phraseid, predictvalue))
    count += 1

print("Completed predictions of test data.")
print("-----------------------------------------")

print("Writing to CSV file")

# write the output to a file
csvwrite(classpredictions)

print("Finished writing to CSV file")

# gs_clf = GridSearchCV(text_clf, parameters)
# gs_clf = gs_clf.fit(train.Phrase, train.Sentiment)
# print(train.Sentiment[gs_clf.predict(['none of which amounts to a good'])[0]])
# print(gs_clf.best_score_)


# for i in range(0, len(testlist)):
