compiled on windows and written by using python 3.5.2
TO OPEN MY PYTHON FILE, YOU WILL NEED TO TYPE THE FOLLOWING:

python textClass.py 