import fileinput
import numpy as np

##Enoch Offiah-1304221


##### PRIOR PROBABILITIES ######
ClassList = []
ClassCnt = []
ClassNo = 5
FeatList = []
FeatCnt = []
FeatNo = 9
posCount = 0
negCount = 0
posTot = []
negTot = []
sent = []
FeatFind = []

## this block of code reads file that acts as the training model
## i.e. sampleTrain.txt
## each line of the file is read and appended to a list called
##ClassList
fileR1 = open('sampleTrain.txt', 'r')
for newLine in fileR1:
    for line in newLine.split():
        sent.append(line)
    ClassList.append(sent)
    sent = []

## these line of code appends the second value of each sublist
## to a new list called ClassCnt
for x in range(len(ClassList)):
    ClassCnt.append(ClassList[x][1])
print()

## this block of code checks the column that indicates
## the class number so that a positive and a negative
## count can be made
## this is then used to calculate the prior probabilities i.e.
## posCount/ClassNo
for i in range(len(ClassCnt)):
    if (ClassCnt[i] == str(1)):
        negCount = negCount + 1
    if (ClassCnt[i] == str(0)):
        posCount = posCount + 1

print('Prior probabilities')
print('class 0 = ', (posCount / ClassNo))
print('class 1 = ', (negCount / ClassNo))
print()

##### FEATURE LIKELIHOODS ######
fileR1 = open('sampleTrain.txt', 'r')
for newLine in fileR1:
    for line in newLine.split():
        sent.append(line)
    FeatList.append(sent)
    sent = []
print(FeatList)
print()

## this is a block of code that separates the features from the vocab
## in order to attempt to perform feature likelihoods on each feature found.
##unfortunately, it was very challenging to implement this in code despite
## having some understanding of the steps required to perform feature likelihood.
## the specific challenge i had was implementing the code to calculate the probability
## for each word.
vCabList = []
itCount = 0
for i in range(len(FeatList)):
    FeatCnt = FeatList[i][2:]
    FeatFind.append(FeatCnt)
for j in range(len(FeatCnt)):
    if (FeatCnt[j] == str(FeatList)):
        negCount = negCount + 1
    if (FeatCnt[j] == str(FeatList)):
        posCount = posCount + 1

for SubList in FeatFind:
    for Item in SubList:
        vCabList.append(Item)
        itCount = itCount + 1
print(vCabList)
print()
print('vocab count: ', itCount)
print()
