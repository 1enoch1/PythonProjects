#Enoch Offiah
#1304221import random

def hmGameplay(sWord, givenLives):
    """
    pulls up a dictionary that holds key values that can be referred to within
    the code. it will be utilised in the 6 functions 
    """
    normal_Word = []
    while len(normal_Word) < len(sWord):
        normal_Word.append("*")
        hmGame = {'secret_Word' : sWord, 'word' : normal_Word, 'Lives' : givenLives}
    return hmGame

def win(hmGame):
    """
    shows whether user has guessed correctly or not
    """
    if '*' in hmGame['word']:
        return False
    else:
        return True

def remLives(hmGame):
    """
    the above values of the dictionary are made accessible 
    """
    return hmGame['Lives']

def hiddenWord(hmGame):
    """
    this function also uses the above values of the dictionary  
    """
    return hmGame['word']

def currentStatus(hmGame):
    """
    a message to the user displaying the amount of lives they have 
    """
    return 'MESSAGE: {} currently you have {} lives left'.format(''.join(hmGame['word']), hmGame['Lives'])

def gameUpdate(hmGame, userGuess):
    """
    monitors and counts the recurrence of certain letters
    """
    occs = 0
    if userGuess in hmGame['secret_Word']:
        for i in range(len(hmGame['secret_Word'])):
            if userGuess== hmGame['secret_Word'][i]:
                hmGame['word'][i] = userGuess
                occs += 1
        return 'your chosen letter {} appears {} in the word'.format(userGuess,occs)
    else:
        hmGame['Lives'] -= 1
        return 'your chosen letter {} does not actually appear in the word!'.format(userGuess)


def playGame(normal_Word, givenLives):
    hmGame = hmGameplay(g_word, r_lives)
    while remLives(hmGame) != 0 and not win(hmGame):
        print(currentStatus(hmGame))  
        while True:
            userGuess = input("please enter a letter: ").upper()
            if len(userGuess) != 1:
                print("Please enter a single letter.")
            elif not userGuess.isalpha():
                print("Please check your input and ensure it is a letter")
            else:
                break
        print(gameUpdate(hmGame, userGuess),'\n')
    if win(hmGame):
        print("WORD: ", hmGame['secret_Word'])
        print("congratulations!- good guessing")
    else:
        print("unlucky! - maybe next time!!")
        print("The actual word was", hmGame['secret_Word'])


def tryAgain():
    """
    allows users the option of attempting the game again 
    """
    print("Do you wish to try again? (yes or no)")
    return input().lower().startswith('y')

def fileAccess():
    """
    attempts to open a presumably valid file otherwise exception is raised
    """
    listedWords = []
    try:
        named_file = input("Enter a file name: ")
        f = open(named_file , "r")
        file_line = f.readlines()
        for i in file_line:
            listedWords.append(i[:-1])
        f.close()
    except IOError:
        print("invalid file{} not found".format(named_file))
        exit()
    return listedWords
    
def retrieveWord(listedWords):
    """
    a random word is picked from an appended list 
    """
    randomWord = random.choice(listedWords)
    return randomWord  

def retrieveLives():
    """
    different lives assigned to each choice provided
    """
    diffChoice=input('\
Please select a difficulty.\n\
1. Easy\n\
2. Intermediate\n\
3. Hard\n\n\
')
    livesCount=0
    while True:
#above is the difficulty level given when the game is initiated 
        if diffChoice == '1':
            return 10
        elif diffChoice == '2':
            return 8
        elif diffChoice == '3':
           return 4
        else :
            print('Invalid Selection')

    
listedWords = fileAccess()
g_word = retrieveWord(listedWords)
r_lives = retrieveLives()
playGame(g_word, r_lives)    

while tryAgain():
    g_word = retrieveWord(listedWords)
    r_lives = retrieveLives()
    playGame(g_word, r_lives)

