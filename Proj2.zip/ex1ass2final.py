#Enoch Offiah
#1304221
import random
import re
class student:
    def __init__(self,reg_Number,yearOfStudy,deg_Scheme,sName,otherNames):
        self.reg_Number = reg_Number
        self.yearOfStudy = yearOfStudy
        self.deg_Scheme = deg_Scheme
        self.sName = sName
        self.otherNames = otherNames
        return student() 
 
##
def showStudent(self):
    print(self.sName,",",self.otherNames,self.reg_Number,self.deg_Scheme,self.yearOfStudy)
    
##
 
myStack =[]
myStack_2=[]
x=0

layout= "{0:<12}{1:<25}{2:<7}{3:<6}{4:<1}"
 
load=True
try:
    file = input("please enter the name of the file that should be read: ")
except IOError:
     print("the file specified does  not exist!, input another filename")
    
try:
    with open(file) as f:
        for line in f:
            y=4
            myStack.append(line)
            notedWords=myStack[x].split()
            x=x+1
            notedWords_length=len(notedWords)
            reg_Number=notedWords[0]
            yearOfStudy="yearOfStudy "+notedWords[1]
            deg_Scheme=notedWords[2]
            otherNames=notedWords[3]
            endLine=notedWords_length-1
            sName=notedWords[endLine]+","
            while y < endLine:
                otherNames=notedWords[y]+" "+otherNames
                y+=1
        
            print(layout.format(sName,otherNames,reg_Number,deg_Scheme,yearOfStudy,))
    userSearch=input("\nhow would you like to search through this file? \n1.degree Scheme\n2.year of study\n3.registration number\n4.quit\n")
    while userSearch!='4':
        if userSearch == '1':
            with open(file) as file_Search:
                firstOption= str(input('please enter a degree scheme:\n'))
                for line in file_Search:
                    if re.search(firstOption,line,re.I):
                        print(line)

                        
        elif userSearch =='2':
            with open(file) as file_Search:
                secondOption= int(input('please enter a year of study(1-4):\n'))
                for line in file_Search:
                    myStack.append(line)
                    notedWords=myStack[x].split()
                    yearOfStudy=int(notedWords[1])
                    if secondOption==yearOfStudy:
                        print(line)
                    x=x+1
 
        elif userSearch =='3':
            with open(file) as file_Search:
                thirdOption=int(input('please enter a registration number:\n'))
                for line in file_Search:
                    myStack.append(line)
                    notedWords=myStack[x].split()
                    reg_Number=int(notedWords[0])
                    if reg_Number==thirdOption:
                        notedWords.remove(notedWords[1])
                        givenWord=(''.join(notedWords))
                        print ('\n',' '.join(map(str,notedWords)))
                        userSearch=input("\nhow would you like to search through this file? \n1.degree Scheme\n2.year of study\n3.registration number\n4.quit\n")
##def tup(x):
##    uname = x[3]+'  '+x[-1]
##    regNo = int(x[0])
##    der = x[2]
##    yer = int(x[1])
##    return uname

                        
                            
                                                        
                                  
except IOError:
    load = False
    print("the file specified does  not exist!, input another filename")

