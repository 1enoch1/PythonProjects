#the value for p is 7
#the value for q is 15
#ENOCH OFFIAH 1304221
file = open("flower.bmp","rb")
data = bytearray(file.read())
file.close()

p = 2
q = 3
header_len = 54

for p in range(1,20):
        for q in range(1,20):
                text_as_bits = bytearray((len(data) - header_len - p) // q)
                for i in range(0, len(text_as_bits)):
                        text_as_bits[i] = data[header_len + p + i * q] & 0b00000001
                        text = bytearray(len(text_as_bits)//8)

                for i in range(0, len(text)):
                        text[i] = 0
                        for j in range(0,8):
                                text[i] = text[i] | (text_as_bits[i * 8 + j] << j)
                                
                file = open("textFound.txt","wb")
                file.write(text)
                file.close()

                fileSearch = open("textFound.txt","r+")
                try:
                        findWords=fileSearch.read()
                        commonWord = 'THE'
                        for commonWord in findWords:
                                print("the values for p: " +str((p)))
                                print("the value for q: "+str((q)))
                                break
                        fileSearch.close()
                except UnicodeDecodeError:
                        pass
                        
	
